class Field{
  int fieldSize = 10;
  //First number of decks, second - amount of ships of that type
  int[][] shipTypesAmount = {{1,4}, {2,3}, {3,2}, {4,1}}; 
  char[][] field = new char[fieldSize][fieldSize];
  void createNewField(){
    for (int i = 0; i < fieldSize; i++){
      for (int j = 0; j < fieldSize; j++){
        this.field[i][j] = '.';
      }
    }
  }
  void generateShips(){
    for(int i = 0; i < shipTypesAmount.length; i++){
      for(int j = 0; j < shipTypesAmount[i][1]; j++){
        Ship ship = new Ship();
        ship.setDecks(shipTypesAmount[i][0]);
        generateNewShip(ship);
        placeOnField(ship);        
      }
    }
  }
  //Randomly generate ships
  void generateNewShip(Ship ship){
    int x;
    int y;
    int direction;
    boolean isGood = false;
    while(!isGood){
      direction = magic(2);
      do{
        x = magic(fieldSize-2) + 1;
        y = magic(fieldSize-2) + 1;
        if(isEmpty(x, y)) {
          isGood = true;
        }
      } while (!isGood);
       switch (direction) {
        case 0 : {
           //test if all cells are empty in this direction
           for(int i = 1; i < ship.decks; i++){
             if(isEmpty(x + i, y) && ((x + i) < (fieldSize - 1))){
               isGood = true;
               } else {
                 isGood = false;
                 break;
                 }
           }
           if(isGood){
              for(int i = 0; i < ship.decks; i++){
                ship.addDeck(x + i, y);
              }
            }
        } 
        break;
        case 1 : {
          for(int i = 1; i < ship.decks; i++){
            if(isEmpty(x, y + i) && ((y + i) < (fieldSize - 1))){
              isGood = true;
              } else {
                isGood = false;
                break;
                } 
          }              
          if(isGood){
              for(int i = 0; i < ship.decks; i++){
                ship.addDeck(x, y + i);
              }
            }
          }
        break;
        }//switch
    }    
  }
//Randomizer
  int magic(int interval){
    return (int)(Math.random()*interval);
  }
  void placeOnField(Ship ship){
    for(int i = 0; i < ship.decks; i++){
      field[ship.decksList.get(i).x][ship.decksList.get(i).y] = 
      ship.decksList.get(i).condition;
    }
  }
  void printField(){
    System.out.print("  ");
    for(int i = 0; i < fieldSize; i++){
      System.out.print((char)(i + 65)+ " ");
    }
    System.out.println("");
    for (int i = 0; i < fieldSize; i++){
      System.out.print(i + " ");
      for (int j = 0; j < fieldSize; j++){
        System.out.print(field[i][j] + " ");
      }
      System.out.println("");
    }
  }
  boolean isEmpty(int x, int y){
    if (field[x][y] == '.') {
      return true;
    } else {
      return false;
      }
  }
}