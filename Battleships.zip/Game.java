import java.util.Scanner;

class Game{
  Scanner sc = new Scanner(System.in);
  
  void start(){
    // System.out.print("Enter your name: ");
    // String playerName = new String(sc.next());
    // clearConsole();
    Field playerField = new Field();
    Field aiField = new Field();
    playerField.createNewField();
    // System.out.println(playerName + "'s board:");
    // playerField.printField();
    aiField.createNewField();
    // System.out.println("Computer's board:");
    // aiField.printField();
    // clearConsole();
    playerField.generateShips();
    aiField.generateShips();
    playerField.printField();
    aiField.printField();


  }
  void clearConsole(){
    System.out.print("\033[H\033[2J");  
    System.out.flush();  
  }
}